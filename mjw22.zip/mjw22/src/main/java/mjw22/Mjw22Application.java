package mjw22;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Mjw22Application {

	public static void main(String[] args) {
		SpringApplication.run(Mjw22Application.class, args);
	}

}
