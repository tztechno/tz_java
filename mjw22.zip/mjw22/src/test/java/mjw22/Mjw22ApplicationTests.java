package mjw22;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Mjw22ApplicationTests {

	@Test
	void contextLoads() {
	}

}
